import spherepacking

run_folder = "temp"


def generate_packing(N,file_name):
    # Delete sphere pack files so runs
    spherepacking.remove_dir(run_folder)

    # Determine radii distribution 
    radii = spherepacking.SphereRadii(
        n = N,
        distribution='lognormal',
        mean=1,
        stdev=0,
        run_folder = run_folder
    )

    spheres = spherepacking.Spheres(radii.radii)

    domain = spherepacking.Domain(
        spheres=spheres,
        porosity=0.4
    )

    domain.gen_min_cube()

    packIO = spherepacking.SpherePackIO(domain,media_type = 'Spheres',run_folder = run_folder, out_folder="data_out")

    sp = packIO.generate_sphere_pack(seed = 333, periodic=True)

    packIO.save_pack_txt(sp,file_name)


if __name__ == '__main__':
    N = [160,250,1290,1980,4350,6680]
    for n,num in enumerate(N):
        file = 'packing_'+str(n+1)
        generate_packing(num,file)